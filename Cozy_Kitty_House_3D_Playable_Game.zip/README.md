# Cozy Kitty House 3D — Playable Browser Game

## Play on Chromebook
1. Open `index.html` in Chrome. The game runs in the browser without installing anything.
2. Use WASD or arrow keys to move. Walk over fish treats to collect them.
3. Change fur colors and outfits, explore the house/garden/park, meet kitty friends, and turn on the cozy tune.
4. On phones/tablets, use the on-screen directional buttons.

## Publish as a browser game
For GitHub Pages, extract the ZIP and upload `index.html` to the root of a public repository, then enable Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
The game is a playable single-file browser prototype. It does not yet include real online multiplayer or Google Play Android packaging.
